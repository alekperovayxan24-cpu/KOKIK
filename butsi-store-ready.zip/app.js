const hasSupabase = window.SUPABASE_URL && !window.SUPABASE_URL.includes("PASTE_");
const sb = hasSupabase ? supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY) : null;

const demoProducts = [
 {id:"1",name:"Football Boots Pro",type:"Мяч",size:"40–45",price:99,old_price:null,image:"",popular:10,discount:false},
 {id:"2",name:"Phantom Luna",type:"Мяч",size:"39–44",price:99,old_price:150,image:"",popular:9,discount:true},
 {id:"3",name:"AIR Zoom Vapor",type:"Мяч",size:"40–45",price:115,old_price:null,image:"",popular:8,discount:false},
 {id:"4",name:"Turf Speed",type:"Turf",size:"39–45",price:89,old_price:120,image:"",popular:7,discount:true}
];

let products=[], cart=JSON.parse(localStorage.getItem("butsiCart")||"[]");

const tr={
ru:{catalog:"Каталог",discounts:"Скидки",about:"О нас",contacts:"Контакты",cart:"Корзина",heroTitle:"Бутсы,<br><strong>которые готовы к игре.</strong>",heroText:"Выбирай модель и размер — оформляй заказ удобно через WhatsApp.",viewCatalog:"Смотреть каталог →",fast:"Быстрый заказ",sizes:"Размеры",sizes2:" указаны у каждого товара",baku:"Баку",delivery:" — доставка и самовывоз",catalogLabel:"КАТАЛОГ",boots:"Футбольные бутсы",search:"Поиск модели...",allTypes:"Все типы",popular:"Сначала популярные",cheap:"Сначала дешевые",expensive:"Сначала дорогие",empty:"Товары не найдены.",aboutText:"Подбираем футбольные, футзальные и turf-бутсы для игры и тренировок. Размер и актуальная цена указаны в карточке товара.",order:"Заказ через WhatsApp",yourCart:"Ваша корзина",total:"Итого",orderWhatsApp:"Заказать через WhatsApp"},
az:{catalog:"Kataloq",discounts:"Endirimlər",about:"Haqqımızda",contacts:"Əlaqə",cart:"Səbət",heroTitle:"Oyuna hazır<br><strong>butlar.</strong>",heroText:"Modeli və ölçünü seçin — sifarişi WhatsApp ilə rahat edin.",viewCatalog:"Kataloqa bax →",fast:"Sürətli sifariş",sizes:"Ölçülər",sizes2:" hər məhsulda göstərilib",baku:"Bakı",delivery:" — çatdırılma və özün götür",catalogLabel:"KATALOQ",boots:"Futbol butları",search:"Model axtar...",allTypes:"Bütün növlər",popular:"Əvvəlcə populyar",cheap:"Əvvəlcə ucuz",expensive:"Əvvəlcə bahalı",empty:"Məhsul tapılmadı.",aboutText:"Oyun və məşqlər üçün futbol, futzal və turf butları təqdim edirik. Ölçü və aktual qiymət məhsul kartında göstərilir.",order:"WhatsApp ilə sifariş",yourCart:"Səbətiniz",total:"Cəmi",orderWhatsApp:"WhatsApp ilə sifariş et"},
en:{catalog:"Catalog",discounts:"Discounts",about:"About us",contacts:"Contacts",cart:"Cart",heroTitle:"Boots<br><strong>ready for the game.</strong>",heroText:"Choose a model and size — place your order easily via WhatsApp.",viewCatalog:"View catalog →",fast:"Quick order",sizes:"Sizes",sizes2:" shown for every product",baku:"Baku",delivery:" — delivery & pickup",catalogLabel:"CATALOG",boots:"Football boots",search:"Search model...",allTypes:"All types",popular:"Most popular",cheap:"Lowest price",expensive:"Highest price",empty:"No products found.",aboutText:"Football, futsal and turf boots for games and training. Size and current price are shown on each product card.",order:"Order via WhatsApp",yourCart:"Your cart",total:"Total",orderWhatsApp:"Order via WhatsApp"}
};

function money(n){return Number(n).toFixed(2).replace(".00","")+" ₼"}
function saveCart(){localStorage.setItem("butsiCart",JSON.stringify(cart));document.querySelector("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
function render(){
 const q=document.querySelector("#search").value.toLowerCase(), type=document.querySelector("#type").value, sort=document.querySelector("#sort").value;
 let list=products.filter(p=>(!q||p.name.toLowerCase().includes(q))&&(!type||p.type===type));
 if(sort==="priceAsc") list.sort((a,b)=>a.price-b.price); else if(sort==="priceDesc") list.sort((a,b)=>b.price-a.price); else list.sort((a,b)=>(b.popular||0)-(a.popular||0));
 document.querySelector("#products").innerHTML=list.map(card).join("");
 const sale=products.filter(p=>p.discount||p.old_price);
 document.querySelector("#discountsGrid").innerHTML=sale.map(card).join("")||'<p class="empty">—</p>';
 document.querySelector("#empty").hidden=list.length>0;
}
function card(p){return `<article class="product">
 <div class="product-img">${p.image?`<img src="${esc(p.image)}" alt="${esc(p.name)}">`:`<span class="noimg">BUTSI</span>`}</div>
 ${(p.discount||p.old_price)?'<span class="tag">− '+(p.old_price?Math.round((1-p.price/p.old_price)*100):'')+'%</span>':''}
 <h3>${esc(p.name)}</h3><div class="meta">${esc(p.type||'')} · ${esc(p.size||'')}</div>
 <div class="price">${money(p.price)} ${p.old_price?`<span class="old">${money(p.old_price)}</span>`:''}</div>
 <button class="add" onclick="addToCart('${p.id}')" data-i18n="cartAdd">В корзину</button></article>`}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
window.addToCart=id=>{const p=products.find(x=>x.id===id);if(!p)return;const x=cart.find(x=>x.id===id);x?x.qty++:cart.push({id,qty:1,name:p.name,price:p.price});saveCart();renderCart();document.querySelector("#cartModal").hidden=false}
function renderCart(){let total=0;document.querySelector("#cartItems").innerHTML=cart.map(x=>{total+=x.price*x.qty;return `<div class="cart-row"><div><b>${esc(x.name)}</b><br>${x.qty} × ${money(x.price)}</div><button onclick="removeCart('${x.id}')">×</button></div>`}).join("")||'<p>—</p>';document.querySelector("#cartTotal").textContent=money(total)}
window.removeCart=id=>{cart=cart.filter(x=>x.id!==id);saveCart();renderCart()}
function setLang(l){localStorage.setItem("butsiLang",l);document.documentElement.lang=l;document.querySelectorAll("[data-i18n]").forEach(e=>{let k=e.dataset.i18n;if(tr[l]?.[k])e.innerHTML=tr[l][k]});document.querySelectorAll("[data-i18n-placeholder]").forEach(e=>{e.placeholder=tr[l]?.[e.dataset.i18nPlaceholder]||e.placeholder})}
async function load(){if(sb){const {data,error}=await sb.from("products").select("*").eq("active",true);if(!error&&data?.length)products=data;else products=demoProducts}else products=demoProducts;render();saveCart()}
document.querySelector("#lang").value=localStorage.getItem("butsiLang")||"ru";setLang(document.querySelector("#lang").value);
document.querySelector("#lang").onchange=e=>setLang(e.target.value);
["search","type","sort"].forEach(id=>document.querySelector("#"+id).oninput=render);
document.querySelector("#cartBtn").onclick=()=>{renderCart();document.querySelector("#cartModal").hidden=false};
document.querySelector("#closeCart").onclick=()=>document.querySelector("#cartModal").hidden=true;
document.querySelector("#orderWhatsApp").onclick=()=>{let text="Здравствуйте! Хочу заказать:%0A"+cart.map(x=>`${x.name} — ${x.qty} шт. × ${x.price} ₼`).join("%0A");window.open("https://wa.me/994707138788?text="+text,"_blank")};
load();