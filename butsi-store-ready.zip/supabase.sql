-- 1) Создайте проект в Supabase.
-- 2) Откройте SQL Editor и выполните весь этот файл.
-- 3) Создайте администратора: Authentication → Users → Add user.
-- 4) Скопируйте его UUID ниже и замените YOUR_ADMIN_USER_UUID.
-- 5) После этого вставьте URL и anon key проекта в config.js.

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type text not null default 'Мяч',
  size text default '',
  price numeric(10,2) not null default 0,
  old_price numeric(10,2),
  image text default '',
  popular integer not null default 0,
  discount boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

insert into public.admins(user_id)
values ('YOUR_ADMIN_USER_UUID')
on conflict do nothing;

alter table public.products enable row level security;
alter table public.admins enable row level security;

drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products"
on public.products for select
using (active = true);

drop policy if exists "Admins can select products" on public.products;
create policy "Admins can select products"
on public.products for select to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products"
on public.products for insert to authenticated
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products"
on public.products for update to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

drop policy if exists "Admins can delete products" on public.products;
create policy "Admins can delete products"
on public.products for delete to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- Доступ к admins с клиента не нужен. RLS не даёт обычным пользователям читать таблицу.
