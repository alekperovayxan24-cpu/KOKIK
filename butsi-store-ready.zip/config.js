// Вставьте сюда данные своего проекта Supabase.
// Их можно получить в Supabase: Project Settings → API.
window.SUPABASE_URL = "PASTE_SUPABASE_URL";
window.SUPABASE_ANON_KEY = "PASTE_SUPABASE_ANON_KEY";