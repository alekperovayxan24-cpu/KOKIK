const configured=window.SUPABASE_URL&&!window.SUPABASE_URL.includes("PASTE_");
const sb=configured?supabase.createClient(window.SUPABASE_URL,window.SUPABASE_ANON_KEY):null;
let editing=null;
const $=id=>document.getElementById(id);
function msg(t){$("loginMsg").textContent=t}
async function start(){
 if(!sb){msg("Сначала настройте Supabase в config.js.");return}
 const {data:{session}}=await sb.auth.getSession(); if(session) showPanel(); else $("loginBox").hidden=false;
 sb.auth.onAuthStateChange((_e,s)=>s?showPanel():location.reload());
}
async function showPanel(){ $("loginBox").hidden=true;$("panel").hidden=false;$("logout").hidden=false;loadProducts()}
$("login").onclick=async()=>{const {error}=await sb.auth.signInWithPassword({email:$("email").value,password:$("password").value});if(error)msg(error.message)}
$("logout").onclick=()=>sb.auth.signOut();
$("newProduct").onclick=()=>{editing=null;clearForm();$("productForm").hidden=false}
$("cancelEdit").onclick=()=>{$("productForm").hidden=true}
$("saveProduct").onclick=async()=>{
 const payload={name:$("pName").value.trim(),type:$("pType").value.trim(),size:$("pSize").value.trim(),price:Number($("pPrice").value),old_price:$("pOld").value?Number($("pOld").value):null,image:$("pImage").value.trim(),popular:Number($("pPopular").value)||0,discount:$("pDiscount").checked,active:true};
 if(!payload.name||!payload.price){$("formMsg").textContent="Введите название и цену.";return}
 let r=editing?await sb.from("products").update(payload).eq("id",editing):await sb.from("products").insert(payload);
 $("formMsg").textContent=r.error?r.error.message:"Сохранено"; if(!r.error){$("productForm").hidden=true;loadProducts()}
}
function clearForm(){["pName","pType","pSize","pPrice","pOld","pImage","pPopular"].forEach(id=>$(id).value="");$("pDiscount").checked=false}
async function loadProducts(){const {data,error}=await sb.from("products").select("*").order("created_at",{ascending:false});if(error){$("adminProducts").innerHTML="<p>"+error.message+"</p>";return}$("adminProducts").innerHTML=(data||[]).map(p=>`<div class="admin-row"><div><b>${esc(p.name)}</b><br><small>${esc(p.type)} · ${esc(p.size)} · ${p.price} ₼</small></div><div><button onclick="editProduct('${p.id}')">Изменить</button> <button onclick="deleteProduct('${p.id}')">Удалить</button></div></div>`).join("")}
window.editProduct=async id=>{const {data}=await sb.from("products").select("*").eq("id",id).single();if(!data)return;editing=id;$("pName").value=data.name||"";$("pType").value=data.type||"";$("pSize").value=data.size||"";$("pPrice").value=data.price||"";$("pOld").value=data.old_price||"";$("pImage").value=data.image||"";$("pPopular").value=data.popular||0;$("pDiscount").checked=!!data.discount;$("productForm").hidden=false}
window.deleteProduct=async id=>{if(confirm("Удалить товар?")){await sb.from("products").delete().eq("id",id);loadProducts()}}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
start();